
function prt(){
	var region0 = $("tbody#authCompView")[0], rows=[]
	rows = $(region0).children().map(function(ind){
		return $(this).innerText
	})
	console.log(rows.length)
}



function updatecol(col, compName){
	var URIs = [
		"http://www.saramin.co.kr/zf_user/search/main?searchword="+compName+"&searchType=search&go=",
		"http://search.incruit.com/list/search.asp?col=job&src=gsw*search&kw="+encodeURI(compName),
		"http://www.jobkorea.co.kr/Search/?stext="+encodeURI(compName)
	]
	var str=""
	str += ", <a href='"+encodeURI(URIs[0])+"' target='_recruit' title='saramin'>SR</a>"
	str += ", <a href='"+(URIs[1])+"' target='_recruit' title='incruit'>IN</a>"
	str += ", <a href='"+(URIs[2])+"' target='_recruit' title='jobkorea'>JK</a>"
	col.innerHTML += str
}
var region0 = $("tbody#authCompView")[0], rows=[]
rows = $(region0).children().map(function(ind){
	if ($(this).children().length > 1){
		linkcol  = $(this).children()[4]
		compName = $(this).children()[1].innerText
		updatecol(linkcol, compName.replace("(주)",""))
	}
})

var region0 = $("tbody#authCompView")[0], rows=[]
row = $(region0).children().get(1)
console.log(row)
//console.log(row[0].innerHTML, row[4].innerHTML)
console.log($(row).children().get(1).innerText)
console.log($(row).children().get(4).innerHTML)



function display_selected_comps(){
	sel_comp_names = ["엔와이티지", "사이버테크프랜드", "에쎄테크놀로지", "알에프엑스소프트",
	"코오롱베니트", "내외정보기술", "엔지아이테크", "코아칩스", "인실리코", "비젠트로",
	"인바이트", "타스코", "유디엠텍", "에프원소프트", "건솔루션", "하티오랩", "로드피아",
	"지엔디비즈", "에이앤지테크놀로지", "쓰리뷰", "네오슬론", "콘웰", "해솔정보시스템"]

	var gengi = $("tbody#authCompView")[0];
	var comps = document.createElement("tbody");
	$(gengi).children().map(function(ind){
		if($(this).children().length > 1){
			var td2 = $(this).children().get(1) // col-1: compname of this-row.
			var compName = $(td2).text().replace("(주)","").replace("주식회사","").trim()
			for(var i=0, len=sel_comp_names.length; i<len; i++){
				if (sel_comp_names[i].indexOf(compName) > -1){
					var td1 = $(this).children().get(0)
					$(td1).css("background-color", "lightgray")
					break;
				}
			}
		}
	})
}
